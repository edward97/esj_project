#
# TABLE STRUCTURE FOR: tbl_divisi
#

DROP TABLE IF EXISTS `tbl_divisi`;

CREATE TABLE `tbl_divisi` (
  `id_divisi` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_divisi` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_divisi`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00001, 'IT Support', '2018-11-01 11:19:50', '2018-11-07 21:01:42');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00003, 'Human Resources', '2018-11-02 13:33:09', '2018-11-07 21:01:51');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00036, 'Consultant', '2018-11-02 13:30:34', '2018-11-07 21:02:07');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00037, 'Accountant', '2018-11-02 13:30:37', '2018-11-07 21:02:13');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00039, 'Sales', '2018-11-02 13:32:13', '2018-11-07 21:02:27');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00040, 'Database Administrator', '2018-11-02 13:32:16', '2018-11-07 21:02:44');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00041, 'Web Developer', '2018-11-02 13:33:06', '2018-11-07 21:02:55');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00054, 'Customer Service', '2018-11-07 14:13:10', '2018-11-07 21:07:37');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00055, 'Retail', '2018-11-07 14:13:12', '2018-11-07 21:07:05');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00056, 'Finance', '2018-11-07 14:13:14', '2018-11-07 21:07:23');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00057, 'Manufacturing', '2018-11-07 14:13:16', '2018-11-07 21:06:54');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00058, 'Chef', '2018-11-07 14:13:18', '2018-11-07 21:06:08');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00059, 'Logistics', '2018-11-07 14:13:20', '2018-11-07 21:05:32');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00060, 'Teacher', '2018-11-07 14:13:24', '2018-11-07 21:04:34');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00061, 'Marketing Manager', '2018-11-07 21:05:07', '2018-11-07 21:05:07');
INSERT INTO `tbl_divisi` (`id_divisi`, `nm_divisi`, `created_at`, `updated_at`) VALUES (00062, 'Marketing Supervisor', '2018-11-07 21:05:11', '2018-11-07 21:05:11');


#
# TABLE STRUCTURE FOR: tbl_items
#

DROP TABLE IF EXISTS `tbl_items`;

CREATE TABLE `tbl_items` (
  `id_item` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_item` varchar(255) NOT NULL,
  `uom` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_items` (`id_item`, `nm_item`, `uom`, `created_at`, `updated_at`) VALUES (00002, 'MOUSE', 'PCS', '2018-11-04 17:55:09', '2018-11-04 17:55:09');
INSERT INTO `tbl_items` (`id_item`, `nm_item`, `uom`, `created_at`, `updated_at`) VALUES (00003, 'LCD', 'UNIT', '2018-11-04 17:55:15', '2018-11-04 17:55:19');
INSERT INTO `tbl_items` (`id_item`, `nm_item`, `uom`, `created_at`, `updated_at`) VALUES (00004, 'UPS', 'UNIT', '2018-11-04 17:56:05', '2018-11-04 17:56:27');
INSERT INTO `tbl_items` (`id_item`, `nm_item`, `uom`, `created_at`, `updated_at`) VALUES (00006, 'KEYBOARD', 'PCS', '2018-11-05 08:44:06', '2018-11-05 08:44:06');
INSERT INTO `tbl_items` (`id_item`, `nm_item`, `uom`, `created_at`, `updated_at`) VALUES (00007, 'PRINTER', 'UNIT', '2018-11-05 08:46:22', '2018-11-05 08:46:22');


#
# TABLE STRUCTURE FOR: tbl_items_detail
#

DROP TABLE IF EXISTS `tbl_items_detail`;

CREATE TABLE `tbl_items_detail` (
  `id_size` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_size` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_item` int(5) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id_size`),
  KEY `id_item` (`id_item`),
  CONSTRAINT `fk_itemdetail_item` FOREIGN KEY (`id_item`) REFERENCES `tbl_items` (`id_item`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00010, 'PROLINK', '2018-11-04 21:49:56', '2018-11-04 21:49:56', 00004);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00012, 'ICA', '2018-11-04 21:50:26', '2018-11-04 21:50:26', 00004);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00013, 'SAMSUNG', '2018-11-04 21:50:49', '2018-11-04 21:50:49', 00003);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00014, 'LG', '2018-11-04 21:50:52', '2018-11-04 21:50:52', 00003);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00015, 'ACER', '2018-11-04 21:50:57', '2018-11-04 21:50:57', 00003);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00017, 'LOGITECH', '2018-11-04 21:51:28', '2018-11-08 09:02:09', 00002);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00020, 'EPSON L110', '2018-11-05 08:46:42', '2018-11-05 08:46:42', 00007);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00021, 'EPSON L120', '2018-11-05 08:46:45', '2018-11-05 08:46:45', 00007);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00022, 'EPSON L360', '2018-11-05 08:46:48', '2018-11-05 08:46:48', 00007);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00023, 'CANON IP2700', '2018-11-05 08:55:57', '2018-11-05 08:55:57', 00007);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00032, 'LOGITECH', '2018-11-07 22:10:28', '2018-11-07 22:10:28', 00006);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00033, 'GENIUS', '2018-11-07 22:10:32', '2018-11-07 22:10:32', 00006);
INSERT INTO `tbl_items_detail` (`id_size`, `nm_size`, `created_at`, `updated_at`, `id_item`) VALUES (00036, 'GENIUS', '2018-11-08 09:02:48', '2018-11-08 09:02:48', 00002);


#
# TABLE STRUCTURE FOR: tbl_po
#

DROP TABLE IF EXISTS `tbl_po`;

CREATE TABLE `tbl_po` (
  `id_po` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_supplier` int(5) unsigned zerofill NOT NULL,
  `id_warehouse` int(5) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id_po`),
  KEY `id_supplier` (`id_supplier`),
  KEY `id_warehouse` (`id_warehouse`),
  CONSTRAINT `fk_po_supplier` FOREIGN KEY (`id_supplier`) REFERENCES `tbl_supplier` (`id_supplier`),
  CONSTRAINT `fk_po_warehouse` FOREIGN KEY (`id_warehouse`) REFERENCES `tbl_warehouse` (`id_warehouse`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_po` (`id_po`, `date`, `description`, `created_at`, `updated_at`, `id_supplier`, `id_warehouse`) VALUES (00030, '2018-11-30 11:51:00', 'TODAY', '2018-11-08 11:52:12', '2018-11-08 11:53:27', 00016, 00010);


#
# TABLE STRUCTURE FOR: tbl_po_detail
#

DROP TABLE IF EXISTS `tbl_po_detail`;

CREATE TABLE `tbl_po_detail` (
  `id_po_detail` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_po_item` varchar(255) NOT NULL,
  `qty` decimal(10,2) NOT NULL,
  `rate` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_po` int(5) unsigned zerofill NOT NULL,
  `id_item` int(5) unsigned zerofill NOT NULL,
  `id_size` int(5) unsigned zerofill NOT NULL,
  PRIMARY KEY (`id_po_detail`),
  KEY `id_po` (`id_po`),
  KEY `id_item` (`id_item`),
  KEY `id_size` (`id_size`),
  CONSTRAINT `fk_podetail_item` FOREIGN KEY (`id_item`) REFERENCES `tbl_items` (`id_item`),
  CONSTRAINT `fk_podetail_po` FOREIGN KEY (`id_po`) REFERENCES `tbl_po` (`id_po`) ON DELETE CASCADE,
  CONSTRAINT `fk_podetail_size` FOREIGN KEY (`id_size`) REFERENCES `tbl_items_detail` (`id_size`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_po_detail` (`id_po_detail`, `nm_po_item`, `qty`, `rate`, `created_at`, `updated_at`, `id_po`, `id_item`, `id_size`) VALUES (00010, 'KEYBOARD-GENIUS', '1.00', '50000.00', '2018-11-08 11:52:12', '2018-11-08 11:52:12', 00030, 00006, 00033);
INSERT INTO `tbl_po_detail` (`id_po_detail`, `nm_po_item`, `qty`, `rate`, `created_at`, `updated_at`, `id_po`, `id_item`, `id_size`) VALUES (00011, 'PRINTER-CANON IP2700', '2.00', '14500.00', '2018-11-08 11:52:12', '2018-11-08 11:52:12', 00030, 00007, 00023);


#
# TABLE STRUCTURE FOR: tbl_supplier
#

DROP TABLE IF EXISTS `tbl_supplier`;

CREATE TABLE `tbl_supplier` (
  `id_supplier` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_supplier` varchar(255) NOT NULL,
  `address` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_supplier`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00006, 'Courttot', 'Hovecrosseport', '2018-11-07 13:04:46', '2018-11-07 21:16:40');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00007, 'Hill Parade', 'Hill Hollies', '2018-11-07 13:04:51', '2018-11-07 21:16:07');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00008, 'Glasgow Garth', 'Newtown Brow', '2018-11-07 13:05:00', '2018-11-07 21:15:51');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00009, 'Harvey Akins', '7950 Ridge Rd', '2018-11-07 14:25:46', '2018-11-07 20:57:40');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00010, 'Angel Martin', '3195 Mapleton Ave', '2018-11-07 14:25:48', '2018-11-07 20:57:54');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00012, 'Desire Morton', '2138 Peaches Way', '2018-11-07 14:25:51', '2018-11-07 20:59:40');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00013, 'Lani Kulana', '3352 Hibiscus Ln', '2018-11-07 14:25:52', '2018-11-07 20:59:24');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00014, 'Mary Worley', '4291 Cherry St', '2018-11-07 14:25:54', '2018-11-07 20:59:08');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00015, 'Carol Brown', '6225 Tamiami Trl', '2018-11-07 14:25:55', '2018-11-07 20:58:56');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00016, 'Larry Hood', '3522 Potter St', '2018-11-07 14:25:58', '2018-11-07 20:58:40');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00017, 'Tanya Hicks', '1487 Potter St', '2018-11-07 14:26:00', '2018-11-07 20:58:25');
INSERT INTO `tbl_supplier` (`id_supplier`, `nm_supplier`, `address`, `created_at`, `updated_at`) VALUES (00019, 'Ken Davidson', '1583 N 27th Rd', '2018-11-08 11:00:16', '2018-11-08 11:00:16');


#
# TABLE STRUCTURE FOR: tbl_users
#

DROP TABLE IF EXISTS `tbl_users`;

CREATE TABLE `tbl_users` (
  `id_user` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_user` varchar(255) NOT NULL,
  `pass_user` varchar(255) NOT NULL,
  `id_divisi` int(6) unsigned zerofill NOT NULL,
  `nav_color` varchar(255) NOT NULL DEFAULT 'chiller-theme',
  `nav_bg` varchar(255) DEFAULT 'bg1',
  `nav_status` varchar(255) DEFAULT 'sidebar-bg',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_user`),
  KEY `id_divisi` (`id_divisi`),
  CONSTRAINT `fk_user_divisi` FOREIGN KEY (`id_divisi`) REFERENCES `tbl_divisi` (`id_divisi`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00001, 'ESJ', '604e1aaea3ffbfc063b9e7e44b25e757', 000001, 'chiller-theme', 'bg2', 'sidebar-bg', '2018-11-02 21:38:30', '2018-11-08 11:01:31');
INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00037, 'EDWARD', '10433f6fa717df9a6b37014d0b816609', 000040, 'chiller-theme', 'bg1', 'sidebar-bg', '2018-11-01 14:25:01', '2018-11-03 12:00:19');
INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00042, 'ADMIN', '73acd9a5972130b75066c82595a1fae3', 000036, 'chiller-theme', 'bg1', 'sidebar-bg', '2018-11-02 13:32:38', '2018-11-03 11:59:23');
INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00043, 'VINZENT', '43d905ca8cefef9bdde0ed4e52169f0f', 000041, 'chiller-theme', 'bg1', 'sidebar-bg', '2018-11-02 13:33:36', '2018-11-03 11:59:16');
INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00044, 'VINA', '8e107d1cf336a6df533f6a1d8a1933bf', 000037, 'chiller-theme', 'bg1', 'sidebar-bg', '2018-11-02 13:35:57', '2018-11-03 11:59:03');
INSERT INTO `tbl_users` (`id_user`, `nm_user`, `pass_user`, `id_divisi`, `nav_color`, `nav_bg`, `nav_status`, `created_at`, `updated_at`) VALUES (00045, 'HENRY', '450ed2e34e0bf66f0aed387cf4585341', 000003, 'chiller-theme', 'bg1', 'sidebar-bg', '2018-11-02 13:41:13', '2018-11-03 11:58:53');


#
# TABLE STRUCTURE FOR: tbl_warehouse
#

DROP TABLE IF EXISTS `tbl_warehouse`;

CREATE TABLE `tbl_warehouse` (
  `id_warehouse` int(5) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `nm_warehouse` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_warehouse`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00001, 'Pearlands', '2018-11-07 11:12:36', '2018-11-07 21:17:50');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00002, 'School End', '2018-11-07 14:27:11', '2018-11-07 21:17:45');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00003, 'Daily Warehouse', '2018-11-07 21:10:52', '2018-11-07 21:10:52');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00004, 'Lifeshop', '2018-11-07 21:10:57', '2018-11-07 21:10:57');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00005, 'Our Warehouse', '2018-11-07 21:11:09', '2018-11-07 21:11:09');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00006, 'Mobi Warehouse', '2018-11-07 21:11:15', '2018-11-07 21:11:15');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00007, 'ShopShoat', '2018-11-07 21:11:26', '2018-11-07 21:11:26');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00008, 'Shophosite', '2018-11-07 21:11:35', '2018-11-07 21:11:35');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00009, 'Spirit Warehouse', '2018-11-07 21:11:45', '2018-11-07 21:11:45');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00010, 'Team Warehouse', '2018-11-07 21:11:51', '2018-11-07 21:11:51');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00011, 'Spy Warehouse', '2018-11-07 21:11:56', '2018-11-07 21:11:56');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00012, 'Yes Warehouse', '2018-11-07 21:12:07', '2018-11-07 21:12:07');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00013, 'Depotbowpot', '2018-11-07 21:12:23', '2018-11-07 21:12:27');
INSERT INTO `tbl_warehouse` (`id_warehouse`, `nm_warehouse`, `created_at`, `updated_at`) VALUES (00014, 'My Warehouse', '2018-11-07 21:12:39', '2018-11-07 21:12:39');


